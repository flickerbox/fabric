# Fabric #

Readme needs to be rewritten, but for now is located here: http://fabric.flickerbox.com
